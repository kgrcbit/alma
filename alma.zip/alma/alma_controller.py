def alma_decision(latency, threshold=0.05):
    """
    ALMA adaptive logic
    """
    if latency > threshold:
        return "SCALE_UP"
    else:
        return "SCALE_DOWN"

