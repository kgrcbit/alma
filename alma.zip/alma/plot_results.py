import pandas as pd
import matplotlib.pyplot as plt

baseline = pd.read_csv("logs/baseline_metrics.csv")
alma = pd.read_csv("logs/alma_metrics.csv")

plt.figure(figsize=(10,5))
plt.plot(baseline["latency_sec"], label="Baseline")
plt.plot(alma["latency_sec"], label="ALMA")
plt.xlabel("Frame index")
plt.ylabel("Latency (seconds)")
plt.title("Latency Comparison: Baseline vs ALMA")
plt.legend()
plt.grid(True)
plt.savefig("latency_comparison.png")
plt.show()

