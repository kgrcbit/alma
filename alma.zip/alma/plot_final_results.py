import pandas as pd
import matplotlib.pyplot as plt

# -----------------------------
# Load ALMA metrics
# -----------------------------
df = pd.read_csv("logs/alma_metrics.csv",
                 names=["batch_id", "latency_ms", "images", "decision"])

# -----------------------------
# LATENCY PLOT
# -----------------------------
plt.figure(figsize=(7,4))
plt.plot(df["batch_id"], df["latency_ms"],
         linewidth=2, marker='o', markersize=4)

plt.xlabel("Batch ID")
plt.ylabel("Latency (ms)")
plt.title("End-to-End Latency (NIH Chest X-ray Streaming)")
plt.grid(True)

plt.tight_layout()
plt.savefig("Figure_latency_chestxray.png", dpi=300)
plt.show()

# -----------------------------
# THROUGHPUT PLOT
# -----------------------------
plt.figure(figsize=(7,4))
plt.plot(df["batch_id"], df["images"],
         linewidth=2, marker='s', markersize=4)

plt.xlabel("Batch ID")
plt.ylabel("Images per Batch")
plt.title("Throughput per Batch (NIH Chest X-ray Streaming)")
plt.grid(True)

plt.tight_layout()
plt.savefig("Figure_throughput_chestxray.png", dpi=300)
plt.show()

# -----------------------------
# ALMA DECISION DISTRIBUTION
# -----------------------------
plt.figure(figsize=(5,4))
df["decision"].value_counts().plot(kind="bar")

plt.xlabel("ALMA Decision")
plt.ylabel("Number of Batches")
plt.title("ALMA Resource Decisions")
plt.grid(axis="y")

plt.tight_layout()
plt.savefig("Figure_alma_decisions.png", dpi=300)
plt.show()

print("All final graphs generated successfully.")

