from kafka import KafkaProducer
import time

producer = KafkaProducer(
    bootstrap_servers='localhost:9092',
    value_serializer=lambda v: v.encode('utf-8')
)

i = 0
while True:
    message = f"frame_{i}"
    producer.send("test", message)
    print("Sent:", message)
    i += 1
    time.sleep(1)

