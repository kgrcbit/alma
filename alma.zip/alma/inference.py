import torch
import time

# Dummy CNN to simulate medical image inference
model = torch.nn.Sequential(
    torch.nn.Conv2d(3, 16, kernel_size=3),
    torch.nn.ReLU(),
    torch.nn.Flatten(),
    torch.nn.Linear(16 * 222 * 222, 2)
)

model.eval()

def run_inference():
    dummy_image = torch.randn(1, 3, 224, 224)
    start = time.time()
    with torch.no_grad():
        _ = model(dummy_image)
    return time.time() - start

