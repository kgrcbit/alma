import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# Correct files (confirmed)
baseline = pd.read_csv("logs/baseline_metrics.csv")
alma = pd.read_csv("logs/alma_metrics.csv")

# Find latency column safely
def get_latency(df):
    for c in df.columns:
        if "latency" in c.lower():
            return df[c].values
    raise ValueError(f"No latency column found: {df.columns}")

lat_base = np.sort(get_latency(baseline))
lat_alma = np.sort(get_latency(alma))

# CDF
cdf_base = np.arange(1, len(lat_base) + 1) / len(lat_base)
cdf_alma = np.arange(1, len(lat_alma) + 1) / len(lat_alma)

# Plot
plt.figure(figsize=(7,5))
plt.plot(lat_base, cdf_base, label="Baseline", linewidth=2)
plt.plot(lat_alma, cdf_alma, label="ALMA", linewidth=2)
plt.axhline(0.95, linestyle="--", color="gray", label="95% threshold")

plt.xlabel("Latency (ms)")
plt.ylabel("Cumulative Distribution Function (CDF)")
plt.title("Latency CDF: Baseline vs ALMA")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.savefig("latency_cdf.png", dpi=300)
plt.show()

