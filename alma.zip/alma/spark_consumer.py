from pyspark.sql import SparkSession

spark = SparkSession.builder \
    .appName("KafkaSparkConsumer") \
    .getOrCreate()

spark.sparkContext.setLogLevel("WARN")

df = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "localhost:9092") \
    .option("subscribe", "test") \
    .option("startingOffsets", "latest") \
    .load()

messages = df.selectExpr("CAST(value AS STRING) AS message")

query = messages.writeStream \
    .outputMode("append") \
    .format("console") \
    .option("truncate", "false") \
    .start()

query.awaitTermination()

