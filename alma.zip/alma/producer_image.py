import os
import cv2
import json
import time
import base64
from kafka import KafkaProducer

# -----------------------------
# CONFIG
# -----------------------------
DATASET_DIR = "dataset/chest_xray"
TOPIC = "image-stream"
BOOTSTRAP = "localhost:9092"

# -----------------------------
# KAFKA PRODUCER
# -----------------------------
producer = KafkaProducer(
    bootstrap_servers=BOOTSTRAP,
    value_serializer=lambda v: json.dumps(v).encode("utf-8")
)

print("Starting image producer...")

for img_name in os.listdir(DATASET_DIR):
    img_path = os.path.join(DATASET_DIR, img_name)

    img = cv2.imread(img_path)
    if img is None:
        continue

    # Encode image as JPEG → Base64
    _, buffer = cv2.imencode(".jpg", img)
    img_b64 = base64.b64encode(buffer).decode("utf-8")

    message = {
        "image_id": img_name,
        "image": img_b64,
        "timestamp": time.time()
    }

    producer.send(TOPIC, value=message)
    print(f"Sent {img_name}")

    # IMPORTANT: slow rate for large medical images
    time.sleep(0.15)

producer.flush()
producer.close()

print("Image producer finished.")

