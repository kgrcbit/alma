from pyspark.sql import SparkSession
from pyspark.sql.functions import col, from_json
from pyspark.sql.types import StructType, StringType, DoubleType
import base64
import cv2
import numpy as np
import time
import os
import csv

# -----------------------------
# SCHEMA
# -----------------------------
schema = StructType() \
    .add("image_id", StringType()) \
    .add("image", StringType()) \
    .add("timestamp", DoubleType())

# -----------------------------
# SPARK SESSION (CREATE FIRST)
# -----------------------------
spark = SparkSession.builder \
    .appName("ALMA-ChestXray-Streaming") \
    .getOrCreate()

# ✅ NOW it is safe to set log level
spark.sparkContext.setLogLevel("ERROR")

# -----------------------------
# READ FROM KAFKA
# -----------------------------
df = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "localhost:9092") \
    .option("subscribe", "image-stream") \
    .load()

parsed = df.select(from_json(col("value").cast("string"), schema).alias("data"))
images = parsed.select("data.*")

# -----------------------------
# IMAGE INFERENCE (SIMULATED)
# -----------------------------
def infer_image(image_b64):
    img_bytes = base64.b64decode(image_b64)
    img_np = np.frombuffer(img_bytes, np.uint8)
    img = cv2.imdecode(img_np, cv2.IMREAD_GRAYSCALE)
    time.sleep(0.02)  # simulate inference time

# -----------------------------
# ALMA PROCESSING
# -----------------------------
LATENCY_THRESHOLD_MS = 500

def process_batch(batch_df, batch_id):
    start = time.time()
    count = batch_df.count()

    if count == 0:
        return

    batch_df.foreach(lambda row: infer_image(row.image))

    latency_ms = (time.time() - start) * 1000

    decision = "SCALE_UP" if latency_ms > LATENCY_THRESHOLD_MS else "STABLE"

    os.makedirs("logs", exist_ok=True)
    with open("logs/alma_metrics.csv", "a", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([batch_id, latency_ms, count, decision])

    print(f"Batch {batch_id} | latency={latency_ms:.2f} ms | images={count} | {decision}")

# -----------------------------
# START STREAM
# -----------------------------
query = images.writeStream \
    .foreachBatch(process_batch) \
    .outputMode("append") \
    .start()

query.awaitTermination()

