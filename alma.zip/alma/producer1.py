from kafka import KafkaProducer
import time
import json
import random

producer = KafkaProducer(
    bootstrap_servers="localhost:9092",
    value_serializer=lambda v: json.dumps(v).encode("utf-8")
)

frame_id = 0

while True:
    message = {
        "frame_id": frame_id,
        "modality": "CT",
        "size": random.choice([224, 256, 512]),
        "timestamp": time.time()
    }

    producer.send("test", message)
    print("Sent:", message)

    frame_id += 1
    time.sleep(1)   # 1 frame/sec (change for load testing)

