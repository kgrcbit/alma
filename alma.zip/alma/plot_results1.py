import pandas as pd
import matplotlib.pyplot as plt

baseline = pd.read_csv("logs/baseline_metrics.csv")
alma = pd.read_csv("logs/alma_metrics.csv")

# Auto-detect numeric latency column
latency_col = baseline.select_dtypes(include="number").columns[0]

print("Using latency column:", latency_col)

plt.figure(figsize=(10,5))
plt.plot(baseline[latency_col], label="Baseline", marker='o')
plt.plot(alma[latency_col], label="ALMA", marker='o')
plt.xlabel("Batch Index")
plt.ylabel("Latency (ms)")
plt.title("Latency Comparison: Baseline vs ALMA")
plt.legend()
plt.grid(True)
plt.savefig("latency_comparison.png")
plt.show()

# Throughput (rows per batch)
if "batch_id" in baseline.columns:
    baseline_tp = baseline.groupby("batch_id").size()
    alma_tp = alma.groupby("batch_id").size()

    plt.figure(figsize=(10,5))
    plt.plot(baseline_tp, label="Baseline Throughput")
    plt.plot(alma_tp, label="ALMA Throughput")
    plt.xlabel("Batch ID")
    plt.ylabel("Messages per Batch")
    plt.title("Throughput Comparison")
    plt.legend()
    plt.grid(True)
    plt.savefig("throughput_comparison.png")
    plt.show()

print("Plots generated successfully.")

