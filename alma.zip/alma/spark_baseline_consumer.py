from pyspark.sql import SparkSession
from pyspark.sql.functions import col, from_json
from pyspark.sql.types import StructType, StructField, StringType, DoubleType, LongType
from inference import run_inference
import time
import csv
import os

spark = SparkSession.builder \
    .appName("Baseline-Kafka-Spark") \
    .getOrCreate()

spark.sparkContext.setLogLevel("WARN")

df = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "localhost:9092") \
    .option("subscribe", "test") \
    .load()

schema = StructType([
    StructField("frame_id", LongType()),
    StructField("modality", StringType()),
    StructField("size", LongType()),
    StructField("timestamp", DoubleType())
])

parsed = df.select(from_json(col("value").cast("string"), schema).alias("data"))
frames = parsed.select("data.*")

os.makedirs("logs", exist_ok=True)
csv_file = "logs/baseline_metrics.csv"

if not os.path.exists(csv_file):
    with open(csv_file, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["batch_id", "frame_id", "latency_sec"])

def process_batch(batch_df, batch_id):
    with open(csv_file, "a", newline="") as f:
        writer = csv.writer(f)
        for row in batch_df.collect():
            latency = run_inference()
            writer.writerow([batch_id, row.frame_id, latency])
            print(f"[BASELINE] latency={latency:.4f}s")

query = frames.writeStream.foreachBatch(process_batch).start()
query.awaitTermination()

